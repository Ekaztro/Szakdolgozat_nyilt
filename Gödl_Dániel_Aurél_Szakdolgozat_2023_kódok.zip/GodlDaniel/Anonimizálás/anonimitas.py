import pandas as pd
import hashlib
import random
from faker import Faker

faker = Faker()
Faker.seed(random.seed(None, 2))  # Ez a két parancs felelős a váletlenszerű nevek létrehozására

excel_file = 'Kurzusok-2021.01.29.xlsx'  # Az excel fájl neve amit használni szeretnénk
database_excel = 'database.xlsx'  # A fájl amibe az összekötő információkat mentyűk le
fin_excel = 'finanonim.xlsx'  # Az a fájl amibe a végeredményt menytűk le
neptun_code = 'Alapértelmezett tárgy kódja'  # Annak az oszlopnak a neve ami tartalmazza a neptun kódokat
names = 'Oktatók'  # Annak az oszlopnka a neve ami tartalmazza a hallgatók neveit


# Itt állitjuk be hogy mit olvasunk be mibe fogunk kiírni és milyen oszlopokat használunk
def Inicialization(source, finish, datab, code, name):
    dataframe = pd.read_excel(source)
    finish_file = pd.ExcelWriter(finish)
    database = pd.ExcelWriter(datab)
    codes = code
    names = name
    return dataframe, finish_file, database, codes, names


# Itt történik meg a kiírás
def to_excel(df, writer):
    df.to_excel(writer, sheet_name='sheetName', index=False)


# Itt állitjuk be az oszlopok méretét a kettő ki írt excelfájlnak
def column_s(df, writer):
    for column in df:
        column_length = max(df[column].astype(str).map(len).max(), len(column))
        col_idx = df.columns.get_loc(column)
        if column_length > 114:
            column_length = 114
        if column_length < 4:
            column_length = 4
        writer.sheets['sheetName'].set_column(col_idx, col_idx, column_length)


def hexacode(cl):
    df[cl] = df[cl].astype(str)  # Az oszlop tartalmának a típusát be állitjuk stringre
    df[cl] = df[cl].apply(lambda x: hashlib.md5(x.encode()).hexdigest()[:15])  # Hashelés hexadecimálisan 15 értékig
    var1 = "uid_"
    df[cl] = var1 + df[cl]  # Hozzáadjuk a változót minden érdékhez az oszlopban


def fakename(names):
    dict_names = {name: faker.name() for name in df[names].unique()}  # A váletlenszerű nevek létrehozása
    df[names] = df[names].map(dict_names)  # A nevek ráfedése az igaziakra


df, writer, datab, code, name = Inicialization(excel_file, fin_excel, database_excel, neptun_code, names)
df2, writer2, datab2, code2, name2 = Inicialization(excel_file, fin_excel, database_excel, neptun_code, names)

hexacode(code)
fakename(name)
df2['Uid'] = df[code]  # Az adatbázisban az oszlophoz hozzá adjuk az értékeket
df2['FakeName'] = df[name]  # Az adatbázisban az oszlophoz hozzá adjuk az értékeket
column = df2[[code2, 'Uid', name2, 'FakeName']]  # Kiemeljük azt a 4 oszlopot ami az adatbázisba kell
dic = column.groupby(code2).agg({code2: 'first', 'Uid': 'first',
                                 name2: 'first', 'FakeName': 'first'})  # Csoportositjuk az adatokat az oszlopokban

to_excel(df, writer)
to_excel(dic, datab2)
column_s(df, writer)
column_s(dic, datab2)

writer.save()
datab2.save()
