import tkinter as tk
from tkinter import messagebox, filedialog
import subprocess


class myGui:

    def __init__(self):
        self.root = tk.Tk()
        self.root.geometry("800x500")
        self.root.title("Excel modifier")
        self.selected_files = [None, None, None]

        self.label = tk.Label(self.root, text="A kapott Neptun adatok módosítása", font=('Ariel', 18))
        self.label.pack(padx=20, pady=20)

        self.browse_button_1 = tk.Button(self.root, text="A módosítani kívánó Excel fájl keresés",
                                         command=lambda: self.browse_file(0))
        self.browse_button_1.pack(padx=10, pady=10)

        self.selected_file_label_1 = tk.Label(self.root, text="")
        self.selected_file_label_1.pack(padx=5, pady=5)

        self.browse_button_2 = tk.Button(self.root, text="A módosításokat tartalmazó Excel fájl keresés",
                                         command=lambda: self.browse_file(1))
        self.browse_button_2.pack(padx=10, pady=10)

        self.selected_file_label_2 = tk.Label(self.root, text="")
        self.selected_file_label_2.pack(padx=5, pady=5)

        self.browse_button_3 = tk.Button(self.root, text="A végeredményt tartalmazó Excel fájl keresés",
                                         command=lambda: self.browse_file(2))
        self.browse_button_3.pack(padx=10, pady=10)

        self.selected_file_label_3 = tk.Label(self.root, text="")
        self.selected_file_label_3.pack(padx=5, pady=5)

        self.button = tk.Button(self.root, text="Ok", font=('Ariel', 15), command=self.process_selected_files,
                                state=tk.DISABLED)
        self.button.pack(padx=10, pady=10)
        self.root.mainloop()

    def show_message(self, message):
        messagebox.showinfo(title="Message", message=message)

    def browse_file(self, file_index):

        file_path = filedialog.askopenfilename(
            filetypes=[("Excel files", "*.xlsx *.xls")]
        )
        if file_path:
            self.selected_files[file_index] = file_path
            self.selected_file_label(file_index).config(text=f"Kiválaszttot fájl: {file_path}")

        if all(self.selected_files) and len(set(self.selected_files)) == 3:
            self.button.config(state=tk.NORMAL)

    def selected_file_label(self, index):
        return [self.selected_file_label_1, self.selected_file_label_2, self.selected_file_label_3][index]

    def process_selected_files(self):
        input_file, modifier_file, output_file = self.selected_files
        try:
            subprocess.run(["python", "oszlop_mod_gui.py", input_file, modifier_file, output_file], check=True)
            self.show_message("Megtörtént!")
        except subprocess.CalledProcessError:
            self.show_message("Hiba történt a feldolgozás során.")


myGui()
