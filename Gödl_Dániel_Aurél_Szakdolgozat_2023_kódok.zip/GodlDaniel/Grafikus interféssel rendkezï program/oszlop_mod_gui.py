import argparse

import pandas as pd
from openpyxl.reader.excel import load_workbook
from openpyxl.styles import Font
import hashlib
import random
from faker import Faker

parser = argparse.ArgumentParser()
parser.add_argument("input_file", help="The input file")
parser.add_argument("mapping_file", help="The mapping file")
parser.add_argument("output_file", help="The output file")
args = parser.parse_args()

faker = Faker()
Faker.seed(random.seed(None, 2))


mapping_df = pd.read_excel(args.mapping_file)
input_df = pd.read_excel(args.input_file)
styled_df = input_df


def Highlight(col):
    if col == "Előadás":
        return 'background-color: lightgreen'
    return ''


def fakename(names):
    dict_names = {name: faker.name() for name in input_df[names].unique()}
    input_df[names] = input_df[names].map(dict_names)


def hexacode(codes):
    input_df[codes] = input_df[codes].astype(str)
    input_df[codes] = input_df[codes].apply(lambda x: hashlib.md5(x.encode()).hexdigest()[:15])
    var1 = "uid_"
    input_df[codes] = var1 + input_df[codes]


for index, row in mapping_df.iterrows():
    original_column = row["Column name"]
    function_name = row["Function"]

    if function_name == "anonym_nc" and original_column in input_df.columns:
        hexacode(original_column)
    elif function_name == "anonym_name" and original_column in input_df.columns:
        fakename(original_column)
    elif function_name == "delete" and original_column in input_df.columns:
        del input_df[original_column]
    elif function_name == "előadás-e" and original_column in input_df.columns:
        styled_df = input_df.style.applymap(Highlight, subset=original_column)

column_mapping = {}
for index, row in mapping_df.iterrows():
    original_column = row["Column name"]
    new_column = row["Rename"]

    if not pd.isna(new_column):
        column_mapping[original_column] = new_column

input_df.rename(columns=column_mapping, inplace=True)

input_df.to_excel(args.output_file, index=False)
styled_df.to_excel(args.output_file, index=False)

wb = load_workbook(args.output_file)
ws = wb.active

for cell in ws[1]:
    cell.font = Font(bold=False)

for column in input_df:
    column_length = max(input_df[column].astype(str).map(len).max(), len(column))
    col_idx = input_df.columns.get_loc(column)
    ws.column_dimensions[chr(65 + col_idx)].width = column_length +1

wb.save(args.output_file)
