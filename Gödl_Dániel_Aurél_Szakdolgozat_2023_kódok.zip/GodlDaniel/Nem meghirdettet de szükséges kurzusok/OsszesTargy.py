import pandas as pd

# Nem voltak meghírdetve de szükséges(nem archív és 2019 után modosítot)
df = pd.read_excel('Osszes_Targy.xlsx')
fin = df[df['Utolsó módosítás ideje'] > '2019-01-01 01:01:01']
final = fin[fin['Archivált'] != True]

# ezek a kiírással és a kinézettel kapcsolatosak
writer = pd.ExcelWriter('finosszestargy.xlsx')
final.to_excel(writer, sheet_name='sheetName', index=False)
for column in df:
    column_length = max(df[column].astype(str).map(len).max(), len(column))
    col_idx = df.columns.get_loc(column)
    writer.sheets['sheetName'].set_column(col_idx, col_idx, column_length)

writer.save()
