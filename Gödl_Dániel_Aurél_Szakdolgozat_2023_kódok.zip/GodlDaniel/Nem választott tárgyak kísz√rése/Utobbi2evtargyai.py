import pandas as pd

# Excel beolvasása
df = pd.read_excel('Utóbbi2ÉvTárgyai.xlsx')

# kiszüri azokat a sorokat ahol az oszlopban az érték nagyobb mint 0
halvol = df[df['Kurzus jelentkezett hallgatói'] > 0]


# ez alapján vannak a cellák szinezve
def Highlight(col):
    if col > 0:
        color = 'white'
    else:
        color = 'red'
    return 'background-color: %s' % color


fin = df.style.applymap(Highlight, subset=['Kurzus jelentkezett hallgatói'])

# ezek a kiírással és a kinézettel kapcsolatosak
writer = pd.ExcelWriter('finutobbi2evtargyai.xlsx')
writer2 = pd.ExcelWriter('finutobbi2evtargyai2.xlsx')
halvol.to_excel(writer, sheet_name='sheetName', index=False, )
fin.to_excel(writer2, sheet_name='sheetName', index=False, )
for column in df:
    column_length = max(df[column].astype(str).map(len).max(), len(column))
    col_idx = df.columns.get_loc(column)
    writer.sheets['sheetName'].set_column(col_idx, col_idx, column_length)
    writer2.sheets['sheetName'].set_column(col_idx, col_idx, column_length)

writer.save()
writer2.save()
