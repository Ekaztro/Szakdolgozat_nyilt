import pandas as pd

# df = pd.read_excel('Kurzusok-2021.09.13.xlsx')
# df = pd.read_excel('Kurzusok-2021.08.28 20.38.xlsx')
# Excel beolvasása
df = pd.read_excel('Kurzusok-2021.01.29.xlsx')
# ez ahoz kellett hogy az teljes letszám egy oszlopba legyen
df['Létszám'] = df['Létszám'] + df['Várólista létszám']
# a szabad helyek oszlop kiszámolása
df['Szabad helyek'] = df['Maximális létszám'] - df['Létszám']
# melyik oszlopok legyenek benne a kimeneti fájlba
cloumnss = df[['Alapértelmezett tárgy kódja', 'Alapértelmezett tárgy neve', 'Létszám',
               'Maximális létszám', 'Szabad helyek']]
# csoportositás a tárgyak kódja alapján
groubed = cloumnss.groupby('Alapértelmezett tárgy kódja').agg(
    {'Alapértelmezett tárgy kódja': 'first', 'Alapértelmezett tárgy neve': 'first', 'Létszám': 'sum',
     'Maximális létszám': 'sum', 'Szabad helyek': 'sum'})


# ez alapján vannak a cellák szinezve
def Highlight(col):
    if col < 0:
        color = 'red'
    else:
        color = 'white'
    return 'background-color: %s' % color


groubed2 = groubed.style.applymap(Highlight, subset=['Szabad helyek'])
print(groubed2)

# ezek a kiírással és a kinézettel kapcsolatosak
writer = pd.ExcelWriter('modified2.xlsx')
groubed2.to_excel(writer, sheet_name='sheetName', index=False, na_rep='NaN')
for column in groubed:
    column_length = max(groubed[column].astype(str).map(len).max(), len(column))
    col_idx = groubed.columns.get_loc(column)
    writer.sheets['sheetName'].set_column(col_idx, col_idx, column_length)

writer.save()
